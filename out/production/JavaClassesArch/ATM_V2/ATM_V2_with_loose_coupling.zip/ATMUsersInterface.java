package ATM_V2;

import java.util.HashMap;

public interface ATMUsersInterface {
    PinUser getThisUserRecord(String pin );
}
